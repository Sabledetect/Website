#!/bin/sh
sysctl net.ipv4.ip_forward=1
ip link set dev $2 up
ip addr add 192.168.137.1/24 dev $2
iptables -t nat -A POSTROUTING -o $1 -j MASQUERADE
iptables -I FORWARD -o $1 -s 192.168.0.0/16 -j ACCEPT
iptables -I INPUT -s 192.168.0.0/16 -j ACCEPT
