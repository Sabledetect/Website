$sPublicAdapterName=$args[0]
$sPrivateAdapterName=$args[1]
write-host "$sPublicAdapterName $sPrivateAdapterName"
# Constants
$public = 0
$private = 1

$m = New-Object -ComObject HNetCfg.HNetShare

$private = $m.EnumEveryConnection |? { $m.NetConnectionProps.Invoke($_).Name -eq $sPrivateAdapterName }
$private_config = $m.INetSharingConfigurationForINetConnection.Invoke($private)

$public = $m.EnumEveryConnection |? { $m.NetConnectionProps.Invoke($_).Name -eq $sPublicAdapterName }
$public_config = $m.INetSharingConfigurationForINetConnection.Invoke($public)

$private_config.DisableSharing()
$public_config.DisableSharing()

Start-Sleep 5

$public_config.EnableSharing(0)
$private_config.EnableSharing(1)